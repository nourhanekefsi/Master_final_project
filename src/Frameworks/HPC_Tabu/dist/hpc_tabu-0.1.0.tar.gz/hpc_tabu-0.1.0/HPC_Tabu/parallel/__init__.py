from .parallel_tabou import ParallelTabouSearch

__all__ = ['ParallelTabouSearch']